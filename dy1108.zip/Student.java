package dy1108;

public class Student {
	//1.필드
	String name;
	String stuid;
	int age;
	static int count;
	//2.생성자
	public Student() {}
	public Student(String name, String stuid, int age) {
		this.name  = name;
		this.stuid = stuid;
		this.age   = age;
		count++;
	}
	//3.메소드
	void printStudent() {
		System.out.println(" 명 = " + count + " , " +  name + " , " + stuid + " , " + age);
	}
}
