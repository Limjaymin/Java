package dy1108;

public class StudentEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Student.count);
		Student kim = new Student("김구", "2201", 20);
		kim.printStudent();
		System.out.println(Student.count);
		Student kang = new Student("강감찬", "2202", 22);
		kang.printStudent();
		System.out.println(Student.count);
		Student iu = new Student("아이유", "2203", 21);
		iu.printStudent();
		System.out.println(Student.count);
		Student jenny = new Student("제니", "2204", 23);
		jenny.printStudent();
	}

}
