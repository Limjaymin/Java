package dy1108;

public class BookEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book littlePrince = new Book("LittlePrince", "생택쥐베리");
		littlePrince.show();
		Book loveStory 	  = new Book("춘향전");
		loveStory.show();
		Book emptyBook = new Book();
		emptyBook.show();
	}

}
		