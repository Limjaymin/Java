package dy1108;

public class CircleArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = new int[10];
		Circle c[] = new Circle[100];
		//똑똑하게 해보기
		for (int i = 0; i < c.length; i++) {
			c[i] = new Circle(i);
		}
		for (int i = 0; i < c.length; i++) {
			System.out.println((int)c[i].getArea() + "\t");
		}
		Circle c1 = new Circle(1);
		System.out.println(c1.add(1, 2));
		System.out.println(c1.add(1, 2, 3));
		System.out.println(c1.add(1.1,  2.4));
	}

}
