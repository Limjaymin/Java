package dy1108;

class Calc {
	public static int abs(int a) {
		//오늘의 키워드 static
		return a>0?a:-a;
	}
	public static int max(int a, int b) {
		return (a>b)?a:b;
	}
	public static int min(int a, int b) {
		return (a>b)?b:a;
	}
}



public class CalcEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Calc c1 = new Calc();
		// c1.abs(-5);
		System.out.println(Calc.abs(-5));
		System.out.println(Calc.max(10, 8));
		System.out.println(Calc.min(10, 8));
		
		System.out.println(Math.abs(-10));
		System.out.println(Math.pow(2, 3));
	}

}
