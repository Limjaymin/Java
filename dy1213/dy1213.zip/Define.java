package dy1213;

public class Define { // 거의 똑같이 낸다고 한다.
	public final static int SAMSUNG = 100; // 삼성전자: 100 
	public final static int APPLE = 200; // 애플:200
	public final static int MI = 300; //샤오미:300
	public final static int ANDROID = 1; // 안드로이드 : 1
	public final static int IOS = 2; // ios:2 // 상수는 대문자로 쓰자
}
