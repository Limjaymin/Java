package dy1213;

public interface PhoneInterface {
	public abstract void sendCall();
	void receiveCall();
}
