package dy1206;

public class WrapperEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		Integer i1 = new Integer(10);
		System.out.println(i1);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		Integer i2 = new Integer("100");
		System.out.println(i2);
		System.out.println(Integer.max(100, 300));
		System.out.println(Integer.min(100, 300));
		*/
		System.out.println(Character.toLowerCase('A'));
		System.out.println(Character.toUpperCase('a'));
		char c1 = '4' , c2 = 'F';
		if (Character.isDigit(c1) == true)
			System.out.println(c1 + "는 숫자");
		if(Character.isAlphabetic(c2))
			System.out.println(c2 + "는 영문자");
		System.out.println(" 점수 = " + Integer.parseInt("100"));
		System.out.println(" 실수 = " + Double.parseDouble("3.14"));
		
	}
}
