package dy1206;

import java.util.ArrayList;

public class ArrayEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> intList = new ArrayList<Integer>();
		intList.add(100);
		intList.add(200);
		intList.add(300);
		for(int i = 0; i < intList.size(); i++) {
			System.out.println(intList.get(i)+"t");
		}
		System.out.println();
		ArrayList<Double> douList = new ArrayList<Double>();
		douList.add(1.2);
		douList.add(2.4);
		for(int i = 0; i<douList.size(); i++) {
			System.out.print(douList.get(i) + "\t");
		}
		System.out.println();
		ArrayList<Student> stuList = new ArrayList<Student>();
		Student hong = new Student("홍길동", "제주도", "010-1111-2222" , 2010, "컴소");
		stuList.add(hong);
		Student son = new Student("손흥민" , "유럽", "010-2222-2222", 2001, "체육");
		stuList.add(son);
		Student lee = new Student("이순신" , "서울", "010-3333-3333", 2202, "체육");
		stuList.add(lee);
		
		for(int i = 0; i<stuList.size(); i++) {
			Student st = stuList.get(i);
			System.out.println(stuList.get(i).getName() + " , " + stuList.get(i).getAddr() + "," + st.getPhone() + st.getStuId() + st.getJeongong());
			
		}
		System.out.println();
		//student중 서울사는 학생의 이름과 전화번호를 출력하시오.
		for(int i=0; i<stuList.size(); i++) {
			if(stuList.get(i).getAddr().equals("서울"))
				System.out.println(stuList.get(i).getName()+stuList.get(i).getPhone());
		}
		//student중 전공이 체육인 학생의 이름과 전화번호를 출력하시오.
		for(int i = 0; i< stuList.size(); i++) {
			if(stuList.get(i).getJeongong().equals("체육"))
				System.out.println(stuList.get(i).getName()+stuList.get(i).getPhone());
		}
		System.out.println();
	
	
	}
}
