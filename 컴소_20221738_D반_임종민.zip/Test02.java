package dy1011;
import java.util.Scanner;
public class Test02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//4명 학생의 국어,영어,수학,미술,체육 점수를 입력하세요. 2차원 배열에 저장하고
		// 0번학생, 국어=, 영어=, 수학=, 미술=, 체육= 합계(정수타입와 평균
		Scanner scanner = new Scanner(System.in);
		System.out.print("4명 학생의 국어,영어,수학,미술,체육 점수를 입력하시요");
		String names[]= {"국어","영어","수학","미술","체육"};
		int intArray[][]=new int[4][5];
		int sum=0;
		int n = intArray.length;
		int m = intArray[0].length;
		for(int i=0; i<intArray.length; i++) {
			sum = 0; 
			for(int j=0; j<intArray[i].length; j++) {
				intArray[i][j]=scanner.nextInt();
				sum+=intArray[i][j];
				System.out.println((i+1) + "번 학생 : ");
				System.out.println(names[j] + "점수:" + intArray[i][j]);
			}
			System.out.println();
			System.out.print("합계:" +sum+ "평균:" +(double)sum/m);
		}
		
	}

}
