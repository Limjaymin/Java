package dy1011;

public class Ex3_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] n = {1,2,3,4,5};
		String names[] = {"사과","배","바나나","체리","딸기","포도"};
		double weight[] = {45.1, 50.2, 53.3, 55.4, 72.6, 75.8, 80.1};
		
		int sum = 0;
		for(int k : n) {
			System.out.print(k + " ");
			sum += k;
		}
		System.out.println("합은" + sum);
		
		for(String s : names)
			System.out.print(s + " ");
		System.out.println();
		double total = 0;
		for (double person : weight) {
			System.out.print(person + " ");
			total += person;
		}
		System.out.println("평균(avg)몸무게=" + total / weight.length);

	}

}
